# Love_message_HTML
lời tỏ tình của chàng coder đơn thân :)

This web page was created based on love tree concept and others source code from the link below:

- [HTML5 Love Tree](http://blog.csdn.net/lisenyang/article/details/35220823)
- [MP3 song] Hãy Cho Anh Ngỏ Lời (Single) - Mai Tiến Dũng (https://zingmp3.vn/album/Hay-Cho-Anh-Ngo-Loi-Single-Mai-Tien-Dung/6UDOBUWE.html)
- [heart eyes emo] Chris Gannon (https://codepen.io/chrisgannon/pen/qBNBRgx)
- [Button moves on hover] Rik Kendell (https://codepen.io/Rikki_Sixx/pen/MYbjXG)

I would like to offer my sincerest "thank you" message to the source code contributors, without your valuable resources I would not be able to finish this mini-project. 
